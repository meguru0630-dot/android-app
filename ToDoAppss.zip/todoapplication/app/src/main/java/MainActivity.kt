package com.example.todoappss

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoappss.TaskAdapter


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // レイアウトを画面にセット

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        // 仮のデータ（リストに表示する内容）
        val sampleTasks = listOf(
            "買い物に行く",
            "宿題をやる",
            "ジムに行く",
            "友達に連絡する",
            "部屋を掃除する"
        )

        // RecyclerViewにアダプターをセット
        val adapter = TaskAdapter(sampleTasks)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // リストに区切り線を追加
        recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
    }
}
